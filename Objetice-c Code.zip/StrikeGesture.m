//
//  StrikeGesture.m
//  iNigma
//
//  Created by Francisco Padilla on 4/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "StrikeGesture.h"
#import	"Machine.h"
#import	"GameFlow.h"

@implementation StrikeGesture

@synthesize tracks, gameMechanics, enabled;

#define minDragVelocity 10 // 100
#define minSlope 0.38
#define minDistance 120


-(id) init
{
    if (self = [super init]) {
        debugString = [[[NSMutableString alloc] init] retain];
    } 
    return self;
}

-(BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent *)event
{
	if (!enabled) {
		return NO;
	}
	firstTouchLocation = [StrikeGesture locationFromTouch:touch];
    
    // Pause Button
	CGSize screenSize = [[CCDirector sharedDirector] winSize ];
	if( CGRectContainsPoint( CGRectMake(0, screenSize.height-60, 60, 60), firstTouchLocation) ){ 
		[[GameFlow sharedGameFlow] pause];
		return NO;
	}
	
	CCSprite *selectedSprite = [self selectSpriteAtLocation:firstTouchLocation];	

    getureInProgress = TRUE;
	lastTouchLocation = CGPointZero;
		
	firstTouchTime = [ touch timestamp ];
	lastTouchTime = 0;
		
	if (streak != nil) {
        [gameMechanics.machine.frontLayer removeChild:streak cleanup:YES];
    }
        
    streak = [CCMotionStreak streakWithFade:0.8f minSeg:1 image:@"pointer.gif" width:13
                                         length:500 color:ccc4(255, 255, 255, 200)];
    [gameMechanics.machine.frontLayer addChild:streak z:5];
	[streak.ribbon addPointAt:firstTouchLocation width:13];

//#ifdef  DEBUG
    [debugString setString:@""];
//#endif
    
	return YES;
}

-(void) ccTouchMoved:(UITouch*)touch withEvent:(UIEvent *)event
{
	if ( ! getureInProgress ) {
		return;
	}
	
	// update last touch information
	currTouchLocation = [StrikeGesture locationFromTouch:touch];
	lastTouchTime = [touch timestamp ];
	
	// calculate and validate minimun touch speed
	double touchVelocity = (firstTouchLocation.x - currTouchLocation.x) / (lastTouchTime - firstTouchTime);
	//NSLog(@"TracksLayer ccTouchMoved: Touch velocity: %e", fabs(touchVelocity) );
	if ( NO && fabs(touchVelocity) < minDragVelocity && abs(firstTouchLocation.x - currTouchLocation.x) > minDistance){
		// NSLog(@"TracksLayer ccTouchMoved: Touch canceled cause velocity is %e below %i", fabs(touchVelocity), minDragVelocity);
		[self cancelTouch];
		return;
	}
	
	// calculate and validate minimum slope
	double slope = (firstTouchLocation.y - currTouchLocation.y) / (firstTouchLocation.x - currTouchLocation.x);
	//	NSLog(@"TracksLayer ccTouchMoved: Touch slop: %e", fabs(slope));
	if (fabs(slope) >= minSlope && abs(firstTouchLocation.x - currTouchLocation.x) > minDistance ) {
		[self cancelTouch];
		//NSLog(@"TracksLayer ccTouchMoved: Touch canceled cause slope %e over maximun %e", fabs(slope), minSlope);
		return;
	}
    
    // interpolate points in case fast swiping
	int deltaX = 70;
    if ( abs(currTouchLocation.x - lastTouchLocation.x) >  deltaX && lastTouchLocation.x && lastTouchLocation.y){
        
        [debugString appendFormat:@"\n interpolation from %f,%f to %f,%f \n",lastTouchLocation.x, lastTouchLocation.y, currTouchLocation.x, currTouchLocation.y];
        
        int numSteps = abs(currTouchLocation.x - lastTouchLocation.x)/deltaX;
        deltaX = deltaX * sign(currTouchLocation.x - lastTouchLocation.x);
        for (int i = 1; i <= numSteps; i++ ){
            CGPoint interpolative = CGPointMake(lastTouchLocation.x + i*deltaX
                                                , lastTouchLocation.y + i*deltaX*slope);
            [self selectSpriteAtLocation:interpolative];
        }
        
        [debugString appendString:@"\n end \n"];
    }
    
	[self selectSpriteAtLocation:currTouchLocation];
	
	[streak.ribbon addPointAt:currTouchLocation width:13];
    lastTouchLocation = currTouchLocation;

}

-(void) ccTouchEnded:(UITouch*)touch withEvent:(UIEvent *)event
{
	if ( ! getureInProgress ) {
		return;
	}
	
	if ( !enabled ) {
		[self cancelTouch];
		return;
	}
    
    lastTouchLocation = [StrikeGesture locationFromTouch:touch];
	[self selectSpriteAtLocation:lastTouchLocation];
	[streak.ribbon addPointAt:lastTouchLocation width:13];

	[gameMechanics validateSelectedSymbols];
	getureInProgress = FALSE;
	[[[gameMechanics machine] frontLayer] removeChild:streak cleanup:YES]; 

//#ifdef  DEBUG
	//NSLog(@"-- StrikeGesture ccTouchEnded \n%@", debugString);
//    [debugString release];
//#endif

}

-(CCSprite*) selectSpriteAtLocation:(CGPoint) location
{
    //NSLog(@"%f  %f", location.x, location.y );
	// grid from 46,52 to 434,255 

    CGSize spriteSize = CGSizeMake(57, 51);
    int trackIndex = 0;
	for( Track *track  in self.tracks ){
        trackIndex ++;
		for (CCSprite *sprite in track.sprites) {
			if ( CGRectContainsPoint( CGRectMake(sprite.position.x - spriteSize.width /2, 
												 sprite.position.y - spriteSize.height/2, 
												 track.trackWidth, 
												 spriteSize.height)
									 , location) ){
				if ( sprite != nil && ((Symbol*)(sprite.userData)).enabled && 
					((Symbol*)(sprite.userData)) != [Symbol emptySymbol] ){
					track.selectedSprite = sprite;
//#ifdef  DEBUG
                    [debugString appendFormat:@"sprite at track %i for point %f,%f \n", trackIndex, location.x, location.y];
//#endif
                    //NSLog();
					return sprite;
				} else {
					return nil;
				}
			}
		}
	}
	return nil;
}


+(CGPoint) locationFromTouch:(UITouch*)touch
{
	CGPoint touchLocation = [touch locationInView: [touch view]];
	return [[CCDirector sharedDirector] convertToGL:touchLocation];
}

#pragma mark effects

-(void) disableSelectedSprites
{
	for ( Track *track  in self.tracks ) {
		[ track disableSelectedSprite ];
	}
}

-(void) check4TouchTimeOver
{
	NSTimeInterval now =  [[NSProcessInfo processInfo] systemUptime];
	
}

-(void) cancelTouch
{
	getureInProgress = FALSE;
	for( Track *track  in self.tracks ){
		track.selectedSprite = nil;
	}
}

-(void) dealloc
{
    if ( streak != nil) {
        //[gameMechanics.machine.frontLayer removeChild:streak cleanup:YES];
    }
    [debugString release];
    [super dealloc];
}

@end
