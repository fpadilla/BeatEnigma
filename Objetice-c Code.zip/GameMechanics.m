//
//  GameMechanics.m
//  iNigma
//
//  Created by Francisco Padilla on 4/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GameMechanics.h"
#import "PopupLayers.h"
#import "Animation.h"
#import "UserTracking.h"
#import "GameCenter.h"
#import "AdManager.h"

#import "Appirater.h"

@implementation GameMechanics

@synthesize trackWidth, machine, levelName, levelIndex, generator, isRunning, phase; 

static BOOL isTimeEnabled;

static GameMechanics *sharedGame;

-(id) initWithParameters:(NSDictionary *)parameters
{
	NSAssert(sharedGame == nil , @"Two GameMechanic Instance");
	
	self = [self init];
	
	minScore = [[parameters objectForKey:@"minScore"] intValue];
	timeOut = [[parameters objectForKey:@"timeOut"] intValue];
	rows = [[parameters objectForKey:@"rows"] intValue];
	multiplier = 1;
	particleSystemFile = @"basic.plist";
	phase = 0;
	isTimeEnabled = YES;
	status = RUNING;
	difficulty = 1.0f;
	
	NSAssert(rows != 0, @"rows paramerter not specified in configuration file");
	
	machineSensitivity = [[parameters objectForKey:@"machineSensitivity"] floatValue];
	
	elapsedTime = 0;
	if (timeOut) {
		elapsedTime = timeOut;
	}
		
	if ( [parameters objectForKey:@"symbolGeneration"] != nil ) {
		CCSpriteFrameCache* frameCache = [CCSpriteFrameCache sharedSpriteFrameCache]; 
		[frameCache addSpriteFramesWithFile:[parameters objectForKey:@"symbolGeneration"]];
		
	}
	
	if ([[parameters objectForKey:@"portraitOrientation"] intValue] == 1 ) { // Default orientation is landscape
		[[CCDirector sharedDirector] setDeviceOrientation:kCCDeviceOrientationPortrait ];
	} else {
        ccDeviceOrientation interfaceOrientation = [[CCDirector sharedDirector] deviceOrientation];
        if( interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown ) {
		}
	}
	
	machine = [[[[Machine alloc] initWithParameters:parameters] autorelease] retain];
	tracksLayer = [[[TracksLayer alloc] initWithParameters:parameters ] autorelease];
	
	// create scene and add layers
	scene = [CCScene node]; 
	[scene addChild:machine.backLayer];
	[scene addChild:tracksLayer z:0 tag:KGameLayer ];
	[scene addChild:machine.frontLayer ];

	// Strike gesture 
	strikeGesture = [[[StrikeGesture alloc] init] autorelease];
	strikeGesture.enabled = YES;
	strikeGesture.tracks = tracksLayer.tracks;
	strikeGesture.gameMechanics = self;
	[strikeGesture retain];
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:strikeGesture priority:0 swallowsTouches:YES ];
	
	[[CCDirector sharedDirector] replaceScene:scene ];
	
	isRunning = YES;
	[[CCScheduler sharedScheduler] scheduleSelector:@selector(updateTime:) forTarget:self interval:1/30 paused:!isRunning ];
	
	
	if ( [@"runtime" isEqualToString:[parameters objectForKey:@"symbolGeneration"] ] 
		   || (timeOut == 0 && minScore == 0) ) {
	
		generator = [[HitGenerator alloc] initWithTracks:tracksLayer.tracks rows:rows];
		[ self updatePhaseParameters ];
    	[machine.frontLayer updateScoreLabel:minHits level:phase];
		//[[CCScheduler sharedScheduler] scheduleSelector:@selector(generateHits) forTarget:generator interval:1/10 paused:!isRunning ];
	}
	
	for (Track *track in tracksLayer.tracks) {
		[ track setupSprites ];
	}
	
	[[CCScheduler sharedScheduler] scheduleSelector:@selector(checkGameOver:) forTarget:self interval:1 paused:!isRunning ];
	[[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"The Higher Mountain.mp3"];
	[[UserTracking sharedUserTracking] Log:START_PLAY];
	
#ifdef GameTesting
	gameTest = [[GameTest alloc] initWithGame:self];
#endif
	
	sharedGame = self;
	return self;
}

+(id) sharedGame
{
	return sharedGame;
}

-(void) dealloc
{
	//[[SimpleAudioEngine sharedEngine]  stopBackgroundMusic];	
	[strikeGesture release];
	[machine release];
	//[scene release];
	sharedGame = nil;
	[super dealloc];
    //NSLog(@"GameMechanics Dealloc:");
}

-(void) stop
{
    [self pause];
    [[CCScheduler sharedScheduler] unscheduleAllSelectorsForTarget:self];
    int count = [self retainCount];
    //NSLog(@"Stop GameMechanics %i retian count:", count);
}

-(void) pause
{
	[tracksLayer stop];
	[[CCScheduler sharedScheduler] pauseTarget:self];
	[[CCScheduler sharedScheduler] pauseTarget:machine];
	[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
	strikeGesture.enabled = NO;
	[machine.frontLayer turnAlarmOff];
	isRunning = NO;
}

-(void) resume
{
	[tracksLayer run];
	[[CCScheduler sharedScheduler] resumeTarget:self];
	[[CCScheduler sharedScheduler] resumeTarget:machine];
	[[SimpleAudioEngine sharedEngine] resumeBackgroundMusic];
	strikeGesture.enabled = YES;
	isRunning = YES;
}

+(id) loadResources
{
	// Sprites
	CCSpriteFrameCache* frameCache = [CCSpriteFrameCache sharedSpriteFrameCache]; 
	[frameCache addSpriteFramesWithFile:@"GameScene.plist"];
	
	// Sound
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"enchant.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"Space vehicle launch.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"Photon gun shot.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"chispas-short.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"chispas.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"Fusion shots.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"fan-stop.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"breaking-ice.caf"];

	[[SimpleAudioEngine sharedEngine] preloadEffect:@"disenchant.caf"];
    [[SimpleAudioEngine sharedEngine] preloadEffect:@"end_explosion.caf"];
	[[SimpleAudioEngine sharedEngine] preloadEffect:@"emergency.caf"];
	[[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:@"The Higher Mountain.mp3"];
	[[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:@"Autobahn-Loophead.mp3"];	
}
#pragma mark Game Symbol Validation Logic

-(void) validateSelectedSymbols
{
	unichar trioCharacter = 'J';
	int trioCount = 0;
	int totalSprites = 0; // number of contiguous sprites
	NSMutableDictionary *stairDict  = [[NSMutableDictionary alloc] initWithCapacity:4 ];	
	BOOL startedSegment = NO;
	for ( Track *track  in tracksLayer.tracks ) {
		
		if ( track.selectedSprite == nil && startedSegment ){
			break;
		} 
		
		if ( track.selectedSprite != nil ){
			startedSegment = YES;
			totalSprites++;
			Symbol *currentSymbol = track.selectedSprite.userData;
			
            if (trioCharacter == 'J' && currentSymbol.character != 'J' ) {
                trioCharacter = currentSymbol.character;
            }
            
			// evaluates for trios
			if ( trioCharacter == currentSymbol.character || currentSymbol.character == 'J' ){
				trioCount++;
			} else if ( trioCharacter == 'J') { // start 
                trioCharacter = currentSymbol.character;
                trioCount++;
            } else {
				trioCharacter = currentSymbol.character;
				trioCount = 1;
			}
			
			// count for unsorted stair  values
			NSString *keyString = [NSString stringWithFormat:@"%C", currentSymbol.character];
			int currValue = 0;
			NSNumber *currNumber = [stairDict objectForKey:keyString];
			if ( currNumber != nil ) {
				currValue = [currNumber intValue];
			}
			[ stairDict setObject:[NSNumber numberWithInt:(++currValue)] forKey:keyString ];
		}
	}// for tracks

	BOOL stairMatch = TRUE;
	for (NSString *key in stairDict ) {
		int hits = [[stairDict objectForKey:key] intValue];
		stairMatch = stairMatch & (hits == 1);
	}

	if (trioCount >=3 && totalSprites == trioCount) {
		hits += (trioCount - 2 );
		[self accountTrio:trioCharacter numSprites:totalSprites ];
	} else if (stairMatch && totalSprites >= 4){
		hits += (totalSprites - 3) ;

        if ( totalSprites > 3 ){ 
            [[GameFlow sharedGameFlow] reportAchievementIdentifier:[NSString stringWithFormat:@"%i",(2000+totalSprites)] percentComplete:100.0];
        }

		[self accountStair:totalSprites ];
	} else {
		[[SimpleAudioEngine sharedEngine] playEffect:@"disenchant.caf"];
		[strikeGesture cancelTouch];
		// NSLog(@"Not match !");		
	}
}

-(void) accountStair:(int)totalSprites
{
	// NSLog(@"stair !");
	[ self updateMeanSpritesPosition ];
	int totalPoints = 45 * multiplier * (isJokerActive?2:1)*(totalSprites-3);
    NSString *labelString = [NSString stringWithFormat:@"+%i points",totalPoints];
    switch (totalSprites) {
        case 5:
            labelString = [NSString stringWithFormat:@"Oh no! +%i",totalPoints];
            break;
        case 6:
            labelString = [NSString stringWithFormat:@"Lucky! +%i",totalPoints];
            break;
        default:
            break;
    }
	[machine.frontLayer showPointLabel:labelString atLocation:averageSpritePos color:ccYELLOW];	
	[self addPoints:totalPoints ];

	[[SimpleAudioEngine sharedEngine] playEffect:currentSndEffect];
	[ self runEffect:'*' atPosition:averageSpritePos withVar: 51*3.5 ];
	
	[strikeGesture disableSelectedSprites];
}

-(void) accountTrio:(unichar)trioCharacter numSprites:(int)totalSprites
{
	[ self updateMeanSpritesPosition ];
	[ self runEffect:trioCharacter atPosition:averageSpritePos withVar:51.5*(totalSprites -1) ];

	[[SimpleAudioEngine sharedEngine] playEffect:currentSndEffect];
	ccColor4B color = [GameMechanics color4type:trioCharacter];
    
	if (trioCharacter =='R') {
		elapsedTime += liveHitValue;
		if (generator != nil) {
			generator.timeUpIndex += liveHitValue/2.4;
		}
		[machine.frontLayer showPointLabel:[NSString stringWithFormat:@"+%i segs", liveHitValue] atLocation:averageSpritePos color:ccc3(color.r, color.g, color.b) ];
	} else if (trioCharacter == 'J') {

		/*if ( phase == 12 ) {
            [[GameFlow sharedGameFlow] reportAchievementIdentifier:@"3001" percentComplete:100.0];

			[self explodeAllScreenSymbols];
		} else {*/

            [[GameFlow sharedGameFlow] reportAchievementIdentifier:@"3000" percentComplete:100.0];
            [self turnJokerOn];		
		//}
	}else {
		int totalPoints = 25 * multiplier * (isJokerActive?2:1) * (totalSprites-2);
        NSString *labelString = [NSString stringWithFormat:@"+%i points",totalPoints];
        switch (totalSprites) {
            case 4:
                labelString = [NSString stringWithFormat:@"Argh! +%i",totalPoints];
                [self turnJokerOn];
                break;
            case 5:
                labelString = [NSString stringWithFormat:@"Ouch! +%i",totalPoints];
                
                CCParticleSystemPoint *particleSys = [CCParticleSystemPoint particleWithFile:@"freezer.plist"];
                slowTimer = SLOW_TIME+1; // enable freeze;
                particleSys.duration = slowTimer;
                particleSys.autoRemoveOnFinish = YES;
                [machine.backLayer addChild:particleSys];
                
                //isTimeEnabled = false;
                //[tracksLayer stop];
                tracksLayer.timeFactor = TIME_SLOW_FACTOR;

                break;
            case 6:
                labelString = [NSString stringWithFormat:@"Damn! +%i",totalPoints];
                [self explodeAllScreenSymbols];
                break;
            default:
                break;
        }
        [machine.frontLayer showPointLabel:labelString atLocation:averageSpritePos color:ccc3(color.r, color.g, color.b)];
		[self addPoints: totalPoints ];

	}

	[strikeGesture disableSelectedSprites];
    
    if ( totalSprites > 3 ){ 
        [[GameFlow sharedGameFlow] reportAchievementIdentifier:[NSString stringWithFormat:@"%i",(1000+totalSprites)] percentComplete:100.0];
    }
}

-(void) runEffect:(unichar)typeEffect atPosition:(CGPoint) position withVar:(float) posVariance
{
	switch (typeEffect) {
		case 'B': 
		case 'D':
		case 'E':
		case 'F':
		case 'X':
		case 'Y':
		case 'Z':			
		case 'W':
		case 'V':			
			particleSystemFile = @"suck.plist";
			break; // phase 3
		case 'R':
			particleSystemFile = @"basic.plist";
			break;
		case '*':
			particleSystemFile = @"joker.plist";
			break;
		default:
			break;
	}
	
	CCParticleSystemPoint *hitParticles = [CCParticleSystemPoint particleWithFile:particleSystemFile];

    // if variance < 51 ( explode all symbols) 
	if ( posVariance < 51 ) {
		hitParticles.totalParticles = hitParticles.totalParticles / 3;
		hitParticles.duration = hitParticles.duration / 3;
	} else if (isJokerActive) {
		hitParticles.speed = 8 * hitParticles.speed;
	}

    ccColor4B color = [GameMechanics color4type:typeEffect];
	hitParticles.startColor = ccc4FFromccc4B( color );
	hitParticles.position = position;
	hitParticles.posVar = CGPointMake(posVariance, 20 );	
	hitParticles.autoRemoveOnFinish = YES;
	[machine.frontLayer addChild: hitParticles];
}

ccColor4B startColor;
+(ccColor4B) color4type:(char) character
{
	switch (character) {
            // blue
		case 'B':   startColor = ccc4(0x00, 0xEF, 0xEF, 255);   break;
            // red
        case 'X':
		case 'D':	startColor = ccc4(0xFF, 0x91, 0x94, 255);   break;
            // green 
        case 'W':
        case 'V':
        case 'Y':
		case 'E':	startColor = ccc4(0x30, 0xF7, 0x01, 255);	break;
            // yellow
        case 'Z':
		case 'F':	startColor = ccc4(0xF7, 0xF4, 0x80, 255);	break;
            
            // white
		case 'R':	startColor = ccc4(0xFF, 0xFF, 0xFF, 255);	break;
		default:	startColor = ccc4(0x28, 0xA2, 0xA4, 128);	break;
	}
    return startColor;
}

-(void) turnJokerOn
{
	jokerTimer = jokerTime;
	isJokerActive = YES ;
	// active joker background
	[machine.frontLayer showPointLabel:[NSString stringWithFormat:@"Code Rush!"] atLocation:averageSpritePos color:ccWHITE];
    [machine.backLayer showJokerBackground:jokerTime];
}

-(void) updateJokerTimer:(ccTime) dt
{
	if (isJokerActive) {
		jokerTimer -= dt;
		if (jokerTimer <= 0) {
			isJokerActive = NO;
			[machine.frontLayer showPointLabel:[NSString stringWithFormat:@"End Code Rush!", liveHitValue] atLocation:ccp(240,160) color:ccWHITE];
		}
	}
}

-(void) checkGameOver:(ccTime) dt
{
	if (timeOut > 0 && elapsedTime <= alarmTime && alarmTime>0 && isTimeEnabled) {
		[machine.frontLayer turnAlarmOn];
	} else if( timeOut > 0 ){
		[machine.frontLayer turnAlarmOff];
	}
	
	/* if (totalScore >= minScore && minScore > 0) {
		[self pause];
		[PopupLayers levelSuccessLayer:0.0f];
	} */
	
	if ( elapsedTime <= 0 && timeOut > 0  && machine.damagePercent < 1 && isTimeEnabled) {
        
        [machine.frontLayer updateTimeLabel:0];
        
#ifdef AutoLevelUp
        machine.damagePercent = 1.0f;
        [self stopPlayingFor:0];
        return;
#endif
        [[GameFlow sharedGameFlow] reportAchievementIdentifier:@"4000" percentComplete: phase/(float)18];

        [self pause];
        
        [[UserTracking sharedUserTracking] Log:END_PLAY points:totalScore phase:phase time:elapsedTime];

#ifdef LITE_VERSION
        [[AdManager sharedAdMgr]  sendAdMobRequest];
#endif
        if (phase >= 4) {
            [Appirater userDidSignificantEvent:YES];
        }
        
        [tracksLayer setOpacity: 80];
		[PopupLayers levelTimeUp:totalScore bonus:0];        

//        [[CCScheduler sharedScheduler] performSelectorInBackground:@selector(sendUnreportedObjects) withObject:[GameCenter sharedGameCenter]];
        [[GameCenter sharedGameCenter] performSelectorInBackground:@selector(sendUnreportedObjects) withObject:nil];

        //[self sendUnreportedObjects]; // Achievements 

        return;
	}
}

-(void) updateMeanSpritesPosition
{
	// calculate average position for point label
	averageSpritePos = CGPointZero;
	int count = 0;
	float minX = 480;
	float maxX = 0;
	for (Track *t in tracksLayer.tracks ){
		if ( t.selectedSprite != nil){
			averageSpritePos = CGPointMake(averageSpritePos.x + t.selectedSprite.position.x, 
										   averageSpritePos.y + t.selectedSprite.position.y);
			count += 1;
			if ( minX > t.selectedSprite.position.x ) { minX = t.selectedSprite.position.x; }
			if ( maxX < t.selectedSprite.position.x ) { maxX = t.selectedSprite.position.x; }
		}
	}
	
	averageSpritePos = CGPointMake(averageSpritePos.x / count, averageSpritePos.y / count + 30);
}

#pragma mark Game and Phase Parameters

-(void) updateTime:(ccTime) dt
{
	
#ifdef GameTesting
	[gameTest update:dt];
#endif
	
	if ( isTimeEnabled ) {
		if ( timeOut ) {
			elapsedTime -= slowTimer ? dt*TIME_SLOW_FACTOR : dt;
		} else {
			elapsedTime += slowTimer ? dt*TIME_SLOW_FACTOR : dt;
		}
	}
	
	[machine.frontLayer updateTimeLabel:elapsedTime];
	[self updateJokerTimer:dt];
	int currentStep = tracksLayer.symbolIndex;
	
    // update freezeTimer
    if (freezeTimer > 0 ) {
        freezeTimer -= dt;
        if (freezeTimer <= 0) {
            freezeTimer = 0;
            [tracksLayer run];
            isTimeEnabled = true;
            //TODO: turn off freeze effect on back layer 
        }
    }
    
    //update slow_timer
    if (slowTimer > 0 ) {
        slowTimer -= dt;
        if (slowTimer <= 0) {
            slowTimer = 0;
            tracksLayer.timeFactor = 1;
            //TODO: turn off slow time effect on back layer 
        }
    }    
	[ self udpateDebugLabel ];
}

-(void) turnPowerUpsOff
{
    freezeTimer = 0;
    [tracksLayer run];
    isTimeEnabled = true;

    slowTimer = 0;
    tracksLayer.timeFactor = 1;
}

-(void) updatePhaseParameters
{
	hits = 0;
	machine.damagePercent = 0;
	[generator reset];
	generator.generationIndex = 0;
	[generator initSymbolArrays:80];	
	[tracksLayer reset];
	tracksLayer.symbolIndex = -1;
	generator.timeUpIndex = 20;
	currentSndEffect = @"enchant.caf";
	alarmTime = 6;
	    
	int totalHits = 20;
	int extraHits = 0; // if not zero then generate extraHits and trio of time character.
	if (phase == 0) {
		phase = 18;
        [machine.frontLayer setPhase:phase];
	} else {
        tracksLayer.symbolIndex = -5 ;
    }
	multiplier = phase;
                                                        // SHELLS
	if (phase == 1) {		
        totalHits = 60;
		minPerformance = 0.05;
		generator.minHits = 1;
		HitGenerator.randomAlphabet = @"BDEF";
		[tracksLayer setSpeed:middleSpeed];
		[self changePauseTracks:0.95];
		Track.random2spaceRatio = 0;
        phaseMsg = @"Batteries Exposed";
	} else if( phase == 2){
        totalHits = 40;
		minPerformance = 0.15;
		generator.minHits = 1;
		HitGenerator.randomAlphabet = @"FDEB";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
                                [NSNumber numberWithFloat:-lowSpeed], [NSNumber numberWithFloat:middleSpeed], [NSNumber numberWithFloat:-hightSpeed],
                                [NSNumber numberWithFloat:+lowSpeed], [NSNumber numberWithFloat:-middleSpeed],[NSNumber numberWithFloat:hightSpeed],
								nil ] ];
		[self changePauseTracks:0.8];
		Track.random2spaceRatio = 0.7;
        phaseMsg = @"Battery Broken";
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
	} else if (phase == 3) {
		minPerformance = 0.3;
		generator.minHits = 1;
        generator.trioStairRatio = 70;
		HitGenerator.randomAlphabet = @"DBEF";
		[tracksLayer setSpeed:middleSpeed];
		[self changePauseTracks:0.8];
		Track.random2spaceRatio = 0;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
		extraHits = 3;
        phaseMsg = @"Coolers Exposed";
	} else if (phase == 4) {
		minPerformance = 0.5;
		generator.minHits = 2;
        generator.trioStairRatio = 60;
		HitGenerator.randomAlphabet = @"DBEF";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
                                [NSNumber numberWithFloat:-hightSpeed], [NSNumber numberWithFloat:middleSpeed], [NSNumber numberWithFloat:-lowSpeed],
                                [NSNumber numberWithFloat:+hightSpeed], [NSNumber numberWithFloat:-middleSpeed],[NSNumber numberWithFloat:lowSpeed],
								nil ] ];
		[self changePauseTracks:0.7];
		Track.random2spaceRatio = 0.7;
        phaseMsg = @"Power Low";
		extraHits = 5;
	}
	//						                                 5
	else if (phase == 5 ) { 
		totalHits = 20;
		minPerformance = 0.5;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"FDEB";
		[self changePauseTracks:0.8];
		Track.random2spaceRatio = 0.7; // 0;
		[tracksLayer setSpeed:127.5];
		extraHits = 6;
        phaseMsg = @"Solar Panels Gone!";
	} else if (phase == 6) {
		totalHits = 10;
		minPerformance = 0.75;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"DEFX";
		[tracksLayer setSpeed:127.5];
		[self changePauseTracks:0.9];
        generator.trioStairRatio = 70;
		Track.random2spaceRatio = 0.5;
        generator.liveHitCount = 2;      // 2 LIVES
		extraHits = 5;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
        phaseMsg = @"Cooler 1 Burned";
	} else if (phase == 7) { // 3
		totalHits = 23;
		minPerformance = 0.7;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"XDEF";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:hightSpeed], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+middleSpeed], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:middleSpeed],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
		extraHits = 8;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
        phaseMsg = @"Top Shell is Down!";
	} 
                                //						FANS
	else if (phase == 8) { 
		totalHits = 26;
		minPerformance = 0.75;
		generator.minHits = 3;
		HitGenerator.randomAlphabet = @"XFBE";
		/*[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:hightSpeed], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+hightSpeed], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:hightSpeed],
								nil ] ];*/
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-hightSpeed], [NSNumber numberWithFloat:25], [NSNumber numberWithFloat:-2*hightSpeed],
								[NSNumber numberWithFloat:+hightSpeed], [NSNumber numberWithFloat:-middleSpeed],[NSNumber numberWithFloat:hightSpeed],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
        generator.trioStairRatio = 10;
        generator.liveHitCount = 2;      
		extraHits = 8;
        phaseMsg = @"Backup is Broken!";
	} else if (phase == 9) {
		totalHits = 26;
		minPerformance = 0.8;
		generator.minHits = 3;
		HitGenerator.randomAlphabet = @"BEFX";
		/*[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:hightSpeed], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+middleSpeed], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:middleSpeed],
								nil ] ];*/
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-middleSpeed], [NSNumber numberWithFloat:hightSpeed], [NSNumber numberWithFloat:-middleSpeed],
								[NSNumber numberWithFloat:+middleSpeed], [NSNumber numberWithFloat:-hightSpeed],[NSNumber numberWithFloat:25],
								nil ] ]; 
		[self changePauseTracks:0];
        generator.trioStairRatio = 50;
		Track.random2spaceRatio = 1;
		extraHits = 3;
        phaseMsg = @"Cooler System Out ";
	} 
	else if (phase == 10 ) { //						RIGHT SIDE metal1
		totalHits = 23;
		minPerformance = 0.7;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"FDEB";
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
		extraHits = 4;
        generator.jokerHitCount = 2;
        generator.jokerInterval = 5;
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25.5f], [NSNumber numberWithFloat:middleSpeed], [NSNumber numberWithFloat:-hightSpeed],
								[NSNumber numberWithFloat:+hightSpeed], [NSNumber numberWithFloat:-middleSpeed],[NSNumber numberWithFloat:25.5],
								nil ] ];
        phaseMsg = @"Isolation Burned";
	} else if (phase == 11 ) {  // cables
		totalHits = 23;
		minPerformance = 0.90;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"DEFX";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-hightSpeed], [NSNumber numberWithFloat:middleSpeed], [NSNumber numberWithFloat:-25.5],
								[NSNumber numberWithFloat:+25.5f], [NSNumber numberWithFloat:-middleSpeed],[NSNumber numberWithFloat:hightSpeed],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
		extraHits = 4;
        phaseMsg = @"Detecting Intrusion!";
	} else if (phase == 12 ) { // metal2  SUPER JOKER
		totalHits = 23;
		minPerformance = 1;
		generator.minHits = 2;
		HitGenerator.randomAlphabet = @"DFZX"; // two color 
		[tracksLayer setSpeed:127.5 ];
		[self changePauseTracks:1];
		Track.random2spaceRatio = 1;
		extraHits = 8;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
        phaseMsg = @"Hacker Detected!";
	} else if (phase == 13) { // metal3
		totalHits = 23;
		minPerformance = 1;
		generator.minHits = 3;
		HitGenerator.randomAlphabet = @"XBEZ";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:hightSpeed], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+middleSpeed], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:middleSpeed],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 0.99;
		extraHits = 8;
        phaseMsg = @"Who are you ?";
	} else if (phase == 14 ) { // lava-hole
		totalHits = 23;
		minPerformance = 1.4;
		generator.minHits = 4;
		HitGenerator.randomAlphabet = @"DEZX";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-middleSpeed], [NSNumber numberWithFloat:25], [NSNumber numberWithFloat:-middleSpeed],
								[NSNumber numberWithFloat:+25], [NSNumber numberWithFloat:-hightSpeed],[NSNumber numberWithFloat:25],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 0.99;
        generator.liveHitCount = 2;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
		extraHits = 5;
        phaseMsg = @"You don't understand!";
	} 

	else if (phase == 15) { //					CHIPS 
		totalHits = 26;
		minPerformance = 0.9;
		generator.minHits = 3;
		HitGenerator.randomAlphabet = @"YEVW";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:75], [NSNumber numberWithFloat:-125],
								[NSNumber numberWithFloat:+175], [NSNumber numberWithFloat:-225],[NSNumber numberWithFloat:275],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 0.8;
		extraHits = 4;
        phaseMsg = @"The World is mine!";
	} else if (phase == 16) {
		totalHits = 26;
		minPerformance = 0.9999;
		generator.minHits = 4;
		HitGenerator.randomAlphabet = @"EVWY";
        [NSNumber numberWithFloat:-275], [NSNumber numberWithFloat:225], [NSNumber numberWithFloat:-175],
        [NSNumber numberWithFloat:+125], [NSNumber numberWithFloat:-75],[NSNumber numberWithFloat:25],
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
		extraHits = 4;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
        phaseMsg = @"I'll beat you!";
	} else if (phase == 17) {
		totalHits = 30;
		minPerformance = 0.8    ;
		generator.minHits = 4;
		HitGenerator.randomAlphabet = @"EVYW";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:25], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+25], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:25],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
        generator.jokerHitCount = 1;
        generator.jokerInterval = 5;
		extraHits = 4;
        phaseMsg = @"Enigma will survive!";
	} else if (phase == 18 ) {
		totalHits = 30;
		minPerformance = 0.8;
		generator.minHits = 4;
		HitGenerator.randomAlphabet = @"WYVE";
		[tracksLayer setSpeeds:[NSArray arrayWithObjects:
								[NSNumber numberWithFloat:-25], [NSNumber numberWithFloat:25], [NSNumber numberWithFloat:-25],
								[NSNumber numberWithFloat:+25], [NSNumber numberWithFloat:-25],[NSNumber numberWithFloat:25],
								nil ] ];
		[self changePauseTracks:0];
		Track.random2spaceRatio = 1;
		extraHits = 4;
        phaseMsg = @"";        
	}
    
	float moveTime = 51/tracksLayer.minSpeed + tracksLayer.pausedTime ;
	elapsedTime = ceilf( (totalHits + (phase!=1?4:0) + 1) * moveTime + 1); // include adjustement for interphase transition
	minHits = minPerformance * totalHits * difficulty;
	if ( extraHits ) {
		generator.timeUpIndex = totalHits;
        if (generator.liveHitCount == 0) {
            generator.liveHitCount = 1;
        }
		generator.liveInterval = extraHits;
		liveHitValue = extraHits * moveTime;
		alarmTime = liveHitValue/2;
		if ( alarmTime < 6 ) {
			alarmTime = 6;
		}
	}
    jokerTime = ceilf(generator.jokerInterval * moveTime);
//    NSLog(@"jokerTime: %f",jokerTime);
	[generator generateHits: totalHits + extraHits*generator.liveHitCount  + rows ];
    		
#ifdef TestLevel
	elapsedTime += liveHitValue;
#endif
	
}

-(void) udpateDebugLabel
{
	machine.frontLayer.debugLabel.string = [NSString stringWithFormat:@"%i  %i.%i   %i.%i.%i  %i", 
											tracksLayer.symbolIndex, generator.liveIndex, generator.jokerIndex, 
											hits, (int)(minPerformance*generator.timeUpIndex), generator.timeUpIndex, phase];
}

-(void) changePauseTracks:(float) apause
{
	for (Track *track in tracksLayer.tracks) {
		track.pausedTime = apause;
	}
    
	tracksLayer.pausedTime = apause;
}

-(void) addPoints:(int) points
{
	totalScore += points;
    [self updateMachineStatus];

}

-(void) updateMachineStatus
{
	machine.damagePercent = hits/(float)minHits;
    
    if (machine.damagePercent >= 1) { // start transition pause & fire assets effects 
        machine.damagePercent = 1;
        [self stopPlayingFor:0];        
    } else {
        [machine.frontLayer updateAssets:machine.damagePercent];
        [machine.frontLayer updateScoreLabel:minHits-hits level:phase];
    }
    
}

#pragma mark End Game & Phase Transition

-(void) stopPlayingFor:(float)time
{
   	[machine.frontLayer updateScoreLabel:0 level:phase];
    
    [self turnPowerUpsOff];
    
#ifdef LITE_VERSION    
    [[AdManager sharedAdMgr]  sendAdMobRequest];
    if (phase == 8) {
        [[machine.frontLayer lastAsset] fireEffects]; // fire screen broken effect
        [[UserTracking sharedUserTracking] Log:END_PLAY points:totalScore phase:phase time:elapsedTime];
        [machine.frontLayer turnAlarmOff];        

        [self endGame];
        return;
    }
#endif
    float rippleTime = 1.5;

    Asset *currentAsset = [machine.frontLayer currentAsset];
    float time4assetAction = [currentAsset.action duration];
    
    if (machine.frontLayer.isAllAssetsDone ) {
        [currentAsset fireEffects];
        [[UserTracking sharedUserTracking] Log:END_PLAY points:totalScore phase:phase time:elapsedTime];
        [self endGame];
        return;
    }

    // update for next asset
    [machine.frontLayer updateAssets:machine.damagePercent];
    
    // FIRE ASSETS EFFECTS    
    [currentAsset runAction:[CCSequence actions:
                             [CCDelayTime actionWithDuration:rippleTime]
                             ,[CCCallFunc actionWithTarget:currentAsset selector:@selector(fireEffects)]
                             ,nil] ];

    // INTER PHASE PAUSE
	isTimeEnabled = NO;
	[[CCScheduler sharedScheduler] pauseTarget:self];
	strikeGesture.enabled = NO;
	[tracksLayer stop];
	[tracksLayer setOpacity: 80];
    
	CCRipple3D *ripple = [CCRipple3D actionWithPosition:ccp(240,160) radius:300 waves:1 amplitude:50 grid:ccg(50,40) duration:rippleTime];
	[tracksLayer runAction:[CCSequence actions: 
					 ripple
					 ,[CCStopGrid action] 
					 ,[CCDelayTime actionWithDuration:time4assetAction]
					 ,[CCCallFunc actionWithTarget:self selector:@selector(resumeFromStopPlaying)]
					 ,nil ] ];

	[machine.backLayer showEmoticon:phase];
    
    if (phase == 1 && [tracksLayer isPerfectLevel]) { // After phase 1
        [[GameFlow sharedGameFlow] reportAchievementIdentifier:@"3002" percentComplete:100.0];
        phaseMsg = @"Perfect Level 1!";
    }

    [machine.frontLayer showPhaseLabel:phaseMsg delay:rippleTime];
    
	phase ++;
	[self updatePhaseParameters];
    
    // JOKER Stuff
    if (isJokerActive) {
        [machine.backLayer hideJoker];
        jokerTimer = 0;
        isJokerActive = NO;
    }
    
    // Alarm Stuff
    [machine.frontLayer turnAlarmOff];        
}

-(void) resumeFromStopPlaying
{
	[tracksLayer run];
	strikeGesture.enabled = YES;
	[tracksLayer setOpacity: 255];
	isTimeEnabled = YES;
	[machine.backLayer hideEmoticon];
	[[CCScheduler sharedScheduler] resumeTarget:self];
	[machine.frontLayer updateScoreLabel:minHits level:phase];
}

-(void) endGame {
    [self pause];
    //tracksLayer.visible = NO;
    [[GameFlow sharedGameFlow] reportAchievementIdentifier:@"4000" percentComplete:100.0];

    [machine.backLayer runAction:[CCSequence actions: 
                                  [CCDelayTime actionWithDuration:5],
                                  [CCHide action], 
                                  nil] ];

    
    [machine.backLayer.emoticon runAction:[CCSequence actions: 
                                           [CCDelayTime actionWithDuration:0.5],
                                           [CCShow action],
                                           [CCFadeTo actionWithDuration:0 opacity:100],
                                           [CCFadeIn actionWithDuration:3], 
                                           nil] ]; 
    
#ifndef LITE_VERSION

    //[machine.frontLayer.openedTop runAction:[CCTintBy actionWithDuration: 5 red:200 green:200 blue:200]];
    [machine.frontLayer runAction: [CCSequence actions:
                                    [CCDelayTime actionWithDuration:3] // pause before explosion broken sceen
                                    ,[PlayEffect actionWithFile:@"end_explosion.caf"]
                                    ,[ShowParticleSystem actionWithParticleSys:[CCParticleSystemPoint particleWithFile:@"end-explosion.plist"] updatePosition:NO]
                                    ,[CCExploteTiles actionWithSeed:3 grid:ccg(48*2.5,32*2.5) duration:5.5]
                                    , nil
                                    ] ];
    //[tracksLayer runAction:[CCFadeOut actionWithDuration:3.0]];
    [tracksLayer runAction:[CCSequence actions: 
                            [CCDelayTime actionWithDuration:5],
                            [CCHide action], 
                            nil] ];

    [PopupLayers levelSuccessLayer:8.5f score:totalScore];
#else
    [PopupLayers levelSuccessLayer:2.0f score:totalScore];

#endif
    
    [[GameCenter sharedGameCenter] performSelectorInBackground:@selector(sendUnreportedObjects) withObject:nil];
    return;
}

#pragma mark Explote All Symbol efect

-(void) explodeAllScreenSymbols
{
	[tracksLayer stop];
	strikeGesture.enabled = NO;
	isTimeEnabled = NO;
	
	// collect noy empty sprites
	NSMutableArray *sprites4explote = [[NSMutableArray alloc] initWithCapacity:36];
	for (Track *track in tracksLayer.tracks ) {
		for (CCSprite *sprite in track.sprites) {
			if ( sprite.userData != [Symbol emptySymbol] && ((Symbol*)sprite.userData).enabled == YES ) {
				[sprites4explote addObject: sprite];
			}
		}
	}
	
	// schedule effects for sprites for all efects 
	float maxTime = 0;
	int estimatedDelay = [sprites4explote count] * 100/3;
	for (CCSprite *sprite in sprites4explote) {
		float delay = (arc4random() % estimatedDelay )/100.0;
		if (delay > maxTime) {
			maxTime = delay;
		}
		
		[sprite runAction:[CCSequence actions:
						   [CCDelayTime actionWithDuration:delay],
						   [CCCallFuncO actionWithTarget:self selector:@selector(explodeSymbol:) object:sprite],
						   nil ]];
	}
	
	// show transition labels
    int numHits = [sprites4explote count] / 3; 
	[machine.frontLayer showBigScore:[NSString stringWithFormat:@"+ %i Hits",numHits] delay:maxTime];

	// start next phase
	[tracksLayer runAction: [CCSequence actions:
						   [CCDelayTime actionWithDuration: maxTime + 1],
                             [CCCallFuncO actionWithTarget:self selector:@selector(startNextPhase:) object:[NSNumber numberWithInt:numHits] ],
						   nil ]];
}

-(void) startNextPhase:(NSNumber *)addhits
{
	strikeGesture.enabled = YES;
	isTimeEnabled = YES;
	[tracksLayer run];
    hits += [addhits intValue];
    [self updateMachineStatus];    
}

-(void) explodeSymbol:(CCSprite*) sprite
{
	// variance = 30;
	[sprite.userData setEnabled: NO];
	[Track updateSpriteFrame:sprite];
	[self runEffect:[sprite.userData character]  atPosition:sprite.position withVar:20 ];
	[[SimpleAudioEngine sharedEngine] playEffect:currentSndEffect];
	[self addPoints:45];
	[machine.frontLayer  updateBigScore:[NSString stringWithFormat:@"%i",totalScore] ];
	[sprite runAction: [CCSequence actions:
						[CCFadeOut actionWithDuration:3],
						nil	] ];
}

@end
