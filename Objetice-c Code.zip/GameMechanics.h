//
//  GameMechanics.h
//  iNigma
//
//  Created by Francisco Padilla on 4/15/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Machine.h"
#import "TracksLayer.h"
#import "StrikeGesture.h"
#import "SimpleAudioEngine.h"
#import "HitGenerator.h"

#define JokerTime 10.0f
#define TIME_SLOW_FACTOR 0.17
#define SLOW_TIME 7
#define FREEZE_TIME 5

//#define TestLevel
//#define GameTesting
//#define AutoLevelUp

@class GameTest;

typedef enum {
	PLAYING = 0,
	PAUSE = 1,
	TRACKDISABLED = 2,
	ASSETRUNNING = 3
} GameStatus;

@interface GameMechanics : NSObject 
{
	float trackWidth;
	Machine	*machine;
	TracksLayer *tracksLayer;
	StrikeGesture *strikeGesture;
	NSString *levelName;
	int levelIndex;
	int totalScore;
	int minScore; // minimun score for pass level
	int hits;
	int minHits;
	int timeOut; // timeOut for complete level 
	int mode; // mode survaival
	float machineSensitivity;
	
@private
	float difficulty;
	int rows;
	CGPoint averageSpritePos;
	float yVar;
	CCScene *scene;
	BOOL isRunning;
    
	int phase;
    NSString *phaseMsg; // message to show up at the end of phase
	float minPerformance;
	
	NSTimeInterval elapsedTime;
	int multiplier; // general multiplier for all hits
	int liveHitValue;
	float alarmTime;

	int jokerHitValue; 
	BOOL isJokerActive;
	float jokerTimer;
    float jokerTime;
    
    float freezeTimer; // timer for freeze symbols
    float slowTimer; // timer for slow timer
	
	NSString *currentSndEffect;
	GameStatus status;
	GameTest *gameTest;
	
	HitGenerator *generator;
	NSString *particleSystemFile;
}

@property(assign) float trackWidth;
@property(assign) int levelIndex;
@property(readwrite) NSString *levelName;
@property(readwrite) Machine *machine;
@property(readonly) GameStatus status;
@property(readonly) HitGenerator *generator;
@property(readonly) BOOL isRunning;
@property(readonly,assign) int phase;

+(id) loadResources;
+(id) sharedGame;
+(ccColor4B) color4type:(char) character;

-(id) initWithParameters:(NSDictionary *)parameters;
-(void) validateSelectedSymbols;
-(void) accountStair:(int)totalSprites;

-(void) updateTime:(ccTime) dt;
-(void) updateJokerTimer:(ccTime) dt;
-(void) stop;
-(void) run;
-(void) runEffect:(unichar)typeEffect atPosition:(CGPoint) position withVar:(float) posVariance;
-(void) changePauseTracks:(float) apause;

-(void) stopPlayingFor:(float) time;
-(void) resumeTemporaryStop;

-(void) explodeAllScreenSymbols;
-(void) startNextPhase:(NSNumber *)addhits;
-(void) explodeSymbol:(CCSprite*) sprite;

-(void) TestUpdateGameParameters;



@end
